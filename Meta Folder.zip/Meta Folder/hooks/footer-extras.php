<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.1.0
    </div>
    <strong>Tequed Labs Management &nbsp;<a href="https://api.whatsapp.com/send?phone=+254708344101">Developed By Team Black Aces contact +254708344101</a>.</strong> All rights
    reserved.
  </footer>